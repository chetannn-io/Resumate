import os
from flask import Flask, request, jsonify
import pdfplumber
import textstat
import nltk
from flask_cors import CORS  # type: ignore # Allows cross-origin requests

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for frontend requests

# Download required NLTK data (only needed once)
nltk.download("punkt")

# Define the uploads folder
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Keywords for skill matching
KEYWORDS = [
    "python", "javascript", "machine learning", "data science",
    "flask", "nlp", "sql", "aws", "docker", "kubernetes", "git"
]

# Root endpoint to verify Flask is running
@app.route("/")
def home():
    return jsonify({"message": "Flask Resume Analyzer is running!"})

def extract_text(file_path):
    """Extracts text from a PDF or TXT file."""
    text = ""
    if file_path.lower().endswith(".pdf"):
        try:
            with pdfplumber.open(file_path) as pdf:
                for idx, page in enumerate(pdf.pages):
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
                    else:
                        print(f"DEBUG: Page {idx+1} has no extractable text.")
        except Exception as e:
            print("DEBUG: PDF extraction error:", e)
            raise Exception("PDF extraction failed. Ensure the PDF contains selectable text.")
    elif file_path.lower().endswith(".txt"):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                text = f.read()
        except Exception as e:
            print("DEBUG: TXT extraction error:", e)
            raise Exception("TXT extraction failed.")
    else:
        raise Exception("Unsupported file format.")
    return text

@app.route("/analyze", methods=["POST"])
def analyze_resume():
    try:
        if "resume" not in request.files:
            return jsonify({"error": "No file provided"}), 400

        file = request.files["resume"]
        if file.filename == "":
            return jsonify({"error": "Empty filename"}), 400

        # Save file securely
        from werkzeug.utils import secure_filename
        filename = secure_filename(file.filename)
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(file_path)
        print("DEBUG: File saved at:", file_path)

        # Log file size
        file_size = os.path.getsize(file_path)
        print("DEBUG: File size:", file_size, "bytes")

        # Extract text from file
        text = extract_text(file_path)
        print("DEBUG: Extracted text length:", len(text))
        if not text.strip():
            return jsonify({"error": "No extractable text found. Ensure the file contains selectable text."}), 400

        # Keyword matching
        text_lower = text.lower()
        found_skills = [kw.capitalize() for kw in KEYWORDS if kw in text_lower]
        missing_skills = sorted(list(set([kw.capitalize() for kw in KEYWORDS]) - set(found_skills)))

        # Readability score
        readability = round(textstat.flesch_reading_ease(text), 2)
        keyword_ratio = (len(found_skills) / len(KEYWORDS)) * 100
        adjusted_readability = readability if readability <= 100 else 100
        overall_score = round((keyword_ratio + adjusted_readability) / 2, 2)

        return jsonify({
            "stored_file": file_path,
            "found_skills": found_skills,
            "missing_skills": missing_skills,
            "readability_score": readability,
            "overall_score": overall_score
        }), 200

    except Exception as e:
        print("DEBUG: Error processing resume:", e)
        return jsonify({"error": "Error processing resume: " + str(e)}), 500

# Global error handler to ensure all errors return JSON
@app.errorhandler(Exception)
def handle_exception(e):
    print("DEBUG: Global exception caught:", e)
    return jsonify({"error": "Internal server error: " + str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)






