import os
import json
import textwrap
from flask import Flask, request, jsonify, send_file
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from flask_cors import CORS

from flask_cors import CORS
app = Flask(__name__)
CORS(app)


DATA_FOLDER = "resumate_storage"
if not os.path.exists(DATA_FOLDER):
    os.makedirs(DATA_FOLDER)

def draw_wrapped_text(c, text, x, y, max_width, line_height, font_name="Helvetica", font_size=12):
    c.setFont(font_name, font_size)
    wrapper = textwrap.TextWrapper(width=90)
    lines = []
    for paragraph in text.split('\n'):
        wrapped = wrapper.wrap(paragraph)
        if not wrapped:
            lines.append("")
        else:
            lines.extend(wrapped)
    for line in lines:
        c.drawString(x, y, line)
        y -= line_height
    return y

@app.route("/save_resume", methods=["POST"])
def save_resume():
    try:
        print("Received /save_resume POST")
        print("Form data:", request.form)
        print("Files:", request.files)
        # Proceed with processing...
        data = {}
        fields = [
            "fullName", "email", "phone", "summary", "education",
            "experience", "skills", "languages", "interests", "conferences", "projects"
        ]
        for field in fields:
            data[field] = request.form.get(field, "")
        username = data.get("fullName", "unknown").replace(" ", "_")
        profile_image = request.files.get("profileImage")
        if profile_image:
            image_filename = f"{username}_profile.jpg"
            image_path = os.path.join(DATA_FOLDER, image_filename)
            profile_image.save(image_path)
            data["image_path"] = image_path
        else:
            data["image_path"] = ""
        file_path = os.path.join(DATA_FOLDER, f"{username}.json")
        with open(file_path, "w") as f:
            json.dump(data, f, indent=4)
        return jsonify({"message": "Resume saved successfully!", "username": username})
    except Exception as e:
        import traceback
        print("Error in /save_resume:", e)
        traceback.print_exc()
        return jsonify({"error": "Internal server error: " + str(e)}), 500

    
    # Save profile image if uploaded
    profile_image = request.files.get("profileImage")
    if profile_image:
        image_filename = f"{username}_profile.jpg"
        image_path = os.path.join(DATA_FOLDER, image_filename)
        profile_image.save(image_path)
        data["image_path"] = image_path
    else:
        data["image_path"] = ""
    
    # Save all form data as JSON for later retrieval
    file_path = os.path.join(DATA_FOLDER, f"{username}.json")
    with open(file_path, "w") as f:
        json.dump(data, f, indent=4)
    return jsonify({"message": "Resume saved successfully!", "username": username})

@app.route("/generate_pdf/<username>", methods=["GET"])
def generate_pdf(username):
    file_path = os.path.join(DATA_FOLDER, f"{username}.json")
    if not os.path.exists(file_path):
        return jsonify({"error": "Resume not found"}), 404
    with open(file_path, "r") as f:
        data = json.load(f)
    
    pdf_path = os.path.join(DATA_FOLDER, f"{username}_resume.pdf")
    c = canvas.Canvas(pdf_path, pagesize=A4)
    width, height = A4

    # ---------------------------
    # HEADER: Large Colored Banner with Photo & Details (Canva-style)
    # ---------------------------
    header_height = 140
    # Draw header background (a modern dark teal)
    c.setFillColorRGB(0.15, 0.30, 0.30)  # a dark, muted teal
    c.rect(0, height - header_height, width, header_height, fill=1, stroke=0)
    
    left_margin = 40
    # Draw candidate photo if available, with rounded border to mimic a circle.
    if data.get("image_path"):
        try:
            img_size = 80
            img_x = left_margin
            img_y = height - header_height + (header_height - img_size) / 2
            # Draw a rounded rectangle as a border (simulate circular mask)
            c.setFillColorRGB(1, 1, 1)
            c.roundRect(img_x - 2, img_y - 2, img_size + 4, img_size + 4, radius=img_size/2, stroke=0, fill=1)
            # Draw the photo inside the border
            c.drawImage(data.get("image_path"), img_x, img_y, width=img_size, height=img_size, preserveAspectRatio=True, mask='auto')
        except Exception as e:
            print("Error drawing image:", e)
        text_x = left_margin + img_size + 20
    else:
        text_x = left_margin

    # Candidate Name (accent color) and Contact Info on header.
    candidate_name = data.get("fullName", "Unknown Name")
    c.setFillColor(colors.HexColor("#00ccff"))  # accent color for name
    c.setFont("Helvetica-Bold", 28)
    c.drawString(text_x, height - header_height/2 + 20, candidate_name)
    
    c.setFillColor(colors.white)
    c.setFont("Helvetica", 12)
    contact_info = f"Email: {data.get('email', '')}    Phone: {data.get('phone', '')}"
    c.drawString(text_x, height - header_height/2 - 10, contact_info)
    
    # ---------------------------
    # BODY: Modern, Spacious Layout
    # ---------------------------
    body_start = height - header_height - 20
    y = body_start - 30

    # Helper to draw section headers with subtle background
    def draw_section_header(title, current_y):
        # Draw a light-inked rectangle (with rounded corners) behind the header text:
        header_bg_color = colors.HexColor("#f2f2f2")
        header_text_color = colors.black
        header_height_local = 22
        margin_x = 40
        # Draw rounded rectangle with a slight fill (simulate a chip)
        c.setFillColor(header_bg_color)
        c.roundRect(margin_x, current_y - header_height_local + 5, width - 2 * margin_x, header_height_local, radius=5, stroke=0, fill=1)
        # Print header text
        c.setFont("Helvetica-Bold", 16)
        c.setFillColor(header_text_color)
        c.drawString(margin_x + 10, current_y - header_height_local + 10, title + ":")
        current_y -= (header_height_local + 8)  # add extra spacing between sections
        return current_y

    # Ensure all non-heading text is in black.
    c.setFillColor(colors.black)

    # Professional Summary
    y = draw_section_header("Professional Summary", y)
    c.setFont("Helvetica", 12)
    y = draw_wrapped_text(c, data.get("summary", ""), 40, y, max_width=width-80, line_height=15)
    y -= 15

    # Education
    y = draw_section_header("Education", y)
    c.setFont("Helvetica", 12)
    y = draw_wrapped_text(c, data.get("education", ""), 40, y, max_width=width-80, line_height=15)
    y -= 15

    # Experience
    y = draw_section_header("Experience", y)
    c.setFont("Helvetica", 12)
    y = draw_wrapped_text(c, data.get("experience", ""), 40, y, max_width=width-80, line_height=15)
    y -= 15

    # Skills
    y = draw_section_header("Skills", y)
    c.setFont("Helvetica", 12)
    for skill in data.get("skills", "").split(","):
        if skill.strip():
            c.drawString(40, y, f"• {skill.strip()}")
            y -= 15
    y -= 10

    # Languages (if provided)
    if data.get("languages"):
        y = draw_section_header("Languages", y)
        c.setFont("Helvetica", 12)
        for lang in data.get("languages").split(","):
            if lang.strip():
                c.drawString(40, y, f"• {lang.strip()}")
                y -= 15
        y -= 10

    # Interests (if provided)
    if data.get("interests"):
        y = draw_section_header("Interests", y)
        c.setFont("Helvetica", 12)
        y = draw_wrapped_text(c, data.get("interests", ""), 40, y, max_width=width-80, line_height=15)
        y -= 10

    # Projects & Certifications (if provided)
    if data.get("projects"):
        y = draw_section_header("Projects & Certifications", y)
        c.setFont("Helvetica", 12)
        y = draw_wrapped_text(c, data.get("projects", ""), 40, y, max_width=width-80, line_height=15)
        y -= 10

    # Conferences & Courses (if provided)
    if data.get("conferences"):
        y = draw_section_header("Conferences & Courses", y)
        c.setFont("Helvetica", 12)
        y = draw_wrapped_text(c, data.get("conferences", ""), 40, y, max_width=width-80, line_height=15)
        y -= 10

    # ---------------------------
    # FOOTER: Branding Information
    # ---------------------------
    c.setFont("Helvetica-Oblique", 10)
    c.setFillColor(colors.gray)
    c.drawCentredString(width/2, 20, "Generated by ResuMate Resume Generator")
    c.save()
    return send_file(pdf_path, as_attachment=True)


if __name__ == "__main__":
    print("Registered endpoints:")
    for rule in app.url_map.iter_rules():
        print(rule)
    app.run(debug=True, port=5000)
