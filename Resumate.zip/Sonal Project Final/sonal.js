// Function to upload resume and analyze
async function uploadResume() {
  const fileInput = document.getElementById("resumeInput");
  clearError();

  if (!fileInput.files.length) {
    showError("Please select a resume file to upload.");
    return;
  }

  const file = fileInput.files[0];
  const formData = new FormData();
  formData.append("resume", file);

  try {
    // Ensure Flask server is reachable before making the request
    const serverCheck = await fetch("http://127.0.0.1:5000/", { method: "GET" });
    if (!serverCheck.ok) {
      throw new Error("Flask server unreachable. Make sure it's running.");
    }

    // Upload the resume for analysis
    const response = await fetch("http://127.0.0.1:5000/analyze", {
      method: "POST",
      body: formData,
      headers: { "Accept": "application/json" }
    });

    // Ensure response is valid JSON
    const data = await response.json().catch(() => {
      throw new Error("Server returned invalid JSON response.");
    });

    if (!response.ok) {
      throw new Error(data.error || "Unknown error occurred.");
    }

    displayResults(data);
  } catch (error) {
    console.error("Upload error:", error);
    showError("Error analyzing your resume: " + error.message);
  }
}

// Function to display results on the page
function displayResults(data) {
  clearError();
  document.getElementById("analysisResults").style.display = "block";
  document.getElementById("storedFilePath").textContent = data.stored_file || "Not saved";
  document.getElementById("found").textContent = data.found_skills.join(", ") || "None";
  document.getElementById("missing").textContent = data.missing_skills.join(", ") || "None";
  document.getElementById("readability").textContent = data.readability_score;
  document.getElementById("overall").textContent = data.overall_score;
}

// Function to display an error message
function showError(message) {
  document.getElementById("analysisResults").style.display = "none";
  let errorContainer = document.getElementById("error") || createErrorContainer();
  errorContainer.textContent = message;
}

// Function to clear previous error messages
function clearError() {
  const errorContainer = document.getElementById("error");
  if (errorContainer) errorContainer.textContent = "";
}

// Utility function to create the error container
function createErrorContainer() {
  const errorContainer = document.createElement("div");
  errorContainer.id = "error";
  errorContainer.style.color = "red";
  errorContainer.style.marginTop = "10px";
  document.body.appendChild(errorContainer);
  return errorContainer;
}


fetch("http://127.0.0.1:5000/save_resume", {
  method: "POST",
  body: formData
})
